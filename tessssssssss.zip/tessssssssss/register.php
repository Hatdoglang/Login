<!-- Christian D. Delapos Section -3A -->
<!-- Clarence Manulat Section-3A -->

<?php
session_start();

include("dp.php");

if($_SERVER['REQUEST_METHOD'] == "POST")
{
    $firstname = isset($_POST['fname']) ? $_POST['fname'] : "";
    $lastname = isset($_POST['lname']) ? $_POST['lname'] : "";
    $username = isset($_POST['username']) ? $_POST['username'] : "";
    $section = isset($_POST['section']) ? $_POST['section'] : "";
    $year = isset($_POST['year']) ? $_POST['year'] : "";
    $schoolid = isset($_POST['school_id']) ? $_POST['school_id'] : "";
    $password = isset($_POST['password']) ? $_POST['password'] : "";

    if(!empty($username) && !empty($password) && !is_numeric($username))
    {
        $query = "insert into form (fname, lname, username, section, year, school_id, password) values ('$firstname', '$lastname','$username','$section', '$year','$schoolid', '$password')";
        mysqli_query($con, $query);
        echo "<script type='text/javascript'> alert('Registration Successfuly')</script>";
    }
    else
    {
        echo "<script type='text/javascript'> alert('Registration Error')</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login and Registration</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="signup">
        <h1>Registration</h1>
        <form method="POST">

          <label>School_id:</label>
            <input type="text" name="school_id" required>

     <label>Section:</label>
        <select name="section" required>
            <option selected="true" disabled="disabled">Select Section</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
        </select>



  
        <label>Year:</label>
        <select name="year" required>
            <option selected="true" disabled="disabled">Select your Year</option>
            <option valschool_idue="1st">1st</option>
            <option value="2nd">2nd</option>
            <option value="3rd">3rd</option>
            <option value="4th">4th</option>
        </select>


            <label>First Name:</label>
            <input type="text" name="fname" required>
            <label>Last name:</label>
            <input type="text" name="lname" required>
            <label>Username:</label>
            <input type="text" name="username" required>
            

     
          

            <label>Password:</label>
            <input type="password" name="password" required>
            <label>Confirm Password:</label>
            <input type="password" name="password" required>
            <input type="submit" name="" value="Submit">
        </form>

        <p>Already have an Account? <a href="login.php">Login Here</a></p>

    </div>
</body>
</html>