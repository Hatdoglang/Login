<?php
$con = mysqli_connect("localhost", "root", "", "registration") or die(mysql_error());
?>
<!-- Christian D. Delapos Section -3A -->
<!-- Clarence Manulat Section-3A -->