<?php
include('dp.php');
?>

<style>
    body{
    height: 360px;
    width: 360px;
    background-color: rgba(255,255,255,0.13);
    position: absolute;
    transform: translate(-50%,-50%);
    top: 50%;
    left: 50%;
    border-radius: 10px;
    backdrop-filter: blur(10px);
    border: 2px solid rgba(255,255,255,0.1);
    box-shadow: 0 0 40px rgba(8,7,16,0.6);
    padding: 50px 35px;
    background: linear-gradient(135deg, #71b7e6, #9b59b6);

    }
    h1{
    text-align:center;
    color: white;
    }
    a{
    color: white;
    position: absolute;
    top: 50%;
    left: 50%;
    padding: 140px 70px;
    font-size: 18px;
    }
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <H1>Welcome Admin</H1>
    <a href="login.php">Logout</a>
</body>
</html>